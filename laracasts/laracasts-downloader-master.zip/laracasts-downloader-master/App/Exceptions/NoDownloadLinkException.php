<?php
/**
 * No download link
 */
namespace App\Exceptions;

use Exception;

class NoDownloadLinkException extends Exception
{
}
