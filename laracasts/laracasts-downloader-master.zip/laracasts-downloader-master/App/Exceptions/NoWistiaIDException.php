<?php
/**
 * No wistia.net ID
 */
namespace App\Exceptions;

use Exception;

class NoWistiaIDException extends Exception
{
}
