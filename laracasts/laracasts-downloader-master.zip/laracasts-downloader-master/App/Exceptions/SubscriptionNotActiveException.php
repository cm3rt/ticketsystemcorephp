<?php
/**
 * Subscription Not Active Exception
 */
namespace App\Exceptions;

use Exception;

/**
 * Class SubscriptionNotActiveException
 * @package App\Exceptions
 */
class SubscriptionNotActiveException extends Exception
{
}
