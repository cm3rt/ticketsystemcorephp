<?php
/**
 * Login Exception
 */
namespace App\Exceptions;

use Exception;

/**
 * Class LoginException
 * @package App\Exceptions
 */
class LoginException extends Exception
{
}
